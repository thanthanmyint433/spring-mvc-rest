﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Layout.Models
{
    public class UpdateCartInput
    {
        public bool Added { get; set; }
        public string ProductId { get; set; }
    }
}
