﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADO.NETWorkshop.Data;
using ADO.NETWorkshop.Models;
using Microsoft.AspNetCore.Mvc;

namespace ADO.NETWorkshop.Controllers
{
   public class CourseController : Controller
   {
      public ActionResult Index()
      {
         List<Course> courses = CourseData.GetAllCourses();

         ViewData["courses"] = courses;

         return View();
      }

      public ActionResult CourseDetails(string sessionId, int courseId)
      {
         Course course = CourseData.GetCourseDetailsByCourseId(courseId);

         ViewData["sessionId"] = sessionId;
         ViewData["course"] = course;

         return View();
      }
   }
}