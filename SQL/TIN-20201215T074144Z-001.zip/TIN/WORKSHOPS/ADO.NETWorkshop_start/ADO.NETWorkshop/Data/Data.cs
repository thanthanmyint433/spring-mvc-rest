﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADO.NETWorkshop.Data
{
   public class Data
   {
      protected static readonly string connectionString = "Server=DESKTOP-D5G8EA8;Database=adoExample; Integrated Security=true";
   }
}
