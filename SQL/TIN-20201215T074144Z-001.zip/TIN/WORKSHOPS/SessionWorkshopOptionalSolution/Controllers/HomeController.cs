﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SessionWorkshop.Data;
using SessionWorkshop.Models;

namespace SessionWorkshop.Controllers
{
   public class HomeController : Controller
   {
      private readonly ILogger<HomeController> _logger;

      public HomeController(ILogger<HomeController> logger)
      {
         _logger = logger;
      }

      public IActionResult Index()
      {
         return View();
      }

      public IActionResult Privacy()
      {
         return View();
      }

      [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
      public IActionResult Error()
      {
         return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
      }

      public IActionResult Login(string username, string password)
      {
         // First of all, check if the request goes with sessionId in the cookies
         string sessionId = Request.Cookies["SessionId"];
         if (sessionId != null)
         {
            // The request send with a sessionId. 
            // We need to verify the sessionId
            Session session = SessionData.GetSessionById(sessionId);
            if (session != null)
            {
               // There's a valid session record in our database.
               // It means, the user has logged in and doesn't need to
               // log in anymore
               return RedirectToAction("Track");
            }
         }

         // If code can reach this line, the user has not logged in


         if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
         {
            // If username and/or password is NOT given, just reload the Login page
            // In reality, you may show the error message
            return View();
         }

         // If code can reach this line, the username and password are given

         User user = UserData.GetUserByUsername(username);         
         if (user == null)
         {
            // Can't find the user, reload the Login page
            // In reality, you may show the error message
            return View();
         }

         if (user.Password != password)
         {
            // Password is incorrect, reload the Login page
            // In reality, you may show the error message
            return View();
         }

         // If code reach this line, login is alright

         // Add the username and also the empty clicked info to the session
         sessionId = Guid.NewGuid().ToString();
         int res = SessionData.CreateSession(new Session
         {
            Id = sessionId,
            UserId = user.Id
         }) ;
         
         if (res != 1)
         {
            // Something wrong with the database
            return StatusCode(500);
         }
      
         // If code reaches this line, creating session into DB is successful

         // Send the sessionId to Client by cookie
         Response.Cookies.Append("SessionId", sessionId);

         // And redirect to the Track page
         return RedirectToAction("Track");
      }

      public IActionResult Track(string clickedBtn)
      {
         Click click;

         string sessionId = Request.Cookies["SessionId"];
         if (sessionId == null)
         {
            // No sessionId is sent in the request, the users need to login
            return RedirectToAction("Login");
         }

         Session session = SessionData.GetSessionById(sessionId);
         if (session == null) {
            // No session is found in the DB, the users need to login
            return RedirectToAction("Login");
         }

         // If reaching this line, a valid session is found

         // User is clicking a new button, so append
         // this event into what has been stored in the DB

         // Retrieve the clicked info fro           
         click = ClickData.GetClickByUserId(session.UserId);

         if (click == null)
         {
            // Create a new click
            ClickData.CreateClick(new Click
            {
               UserId = session.UserId,
               ClickButtons = clickedBtn
            });
         }
         else
         {
            // Add the new clicked button and store back to the session
            ClickData.UpdateClick(new Click
            {
               UserId = session.UserId,
               ClickButtons = click.ClickButtons + " " + clickedBtn
            });
         }

         // Here, the controller needs to retrieve the model data to send to view
         // for generating HTML
         // The data includes username and clicked buttons
         // Both can be retrieved using userId
         User user = UserData.GetUserById(session.UserId);
         if (user != null)
            ViewData["username"] = user.Username;

         click = ClickData.GetClickByUserId(session.UserId);
         if (click != null)
            ViewData["clickedButtons"] = click.ClickButtons;

         return View();
      }

      public IActionResult Logout() {
         string sessionId = Request.Cookies["SessionId"];
         if (sessionId == null)
         {
            // No sessionId is sent in the request, the users need to login
            return RedirectToAction("Login");
         }
         
         // User decides to log out, clear the session and redirect to login page
         int res = SessionData.DeleteSesion(sessionId);
         if (res != 1)
         {
            // Something wrong with the DB
            return StatusCode(500);
         }

         // Delete the sessionId in cookie as well.
         // This is OPTIONAL because even if sessionId is sent, it's not valid 
         // in our DB anymore
         Response.Cookies.Delete("SessionId");

         // Done, now redirect the user to login page
         return RedirectToAction("Login", "Home");
      }
   }
}
