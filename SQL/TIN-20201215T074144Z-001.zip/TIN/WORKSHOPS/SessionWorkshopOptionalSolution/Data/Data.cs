﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SessionWorkshop.Data
{
   public class Data
   {
      protected static readonly string connectionString = @"Server=ISS8361007539A\SQLEXPRESS;Database=SessionsWorkshop; Integrated Security=true";
   }
}
