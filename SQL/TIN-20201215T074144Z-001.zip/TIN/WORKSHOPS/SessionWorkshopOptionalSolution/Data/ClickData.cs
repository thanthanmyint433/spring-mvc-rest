﻿using SessionWorkshop.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SessionWorkshop.Data
{
   public class ClickData : Data
   {
      public static Click GetClickByUserId(int userId)
      {
         Click click = null;

         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            string sql = @"SELECT UserId, ClickedButtons
                           FROM Clicks
                           WHERE UserId = " + userId ;
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
               return new Click
               {
                  UserId = (int)reader["UserId"],
                  ClickButtons = ((string)reader["ClickedButtons"]).Trim()
               };

            }
         }

         return click;
      }

      public static int CreateClick(Click click)
      {
         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            string sql = string.Format("INSERT INTO Clicks(UserId, ClickedButtons) " +
                                                   "VALUES ({0}, '{1}')", click.UserId, click.ClickButtons);
            SqlCommand cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteNonQuery();
         }
      }

      public static int UpdateClick(Click click)
      {
         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            string sql = string.Format("UPDATE Clicks " +
                                          "SET ClickedButtons ='{1}' " +
                                          "WHERE UserId = {0}", click.UserId, click.ClickButtons);
            SqlCommand cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteNonQuery();
         }
      }
   }
}
