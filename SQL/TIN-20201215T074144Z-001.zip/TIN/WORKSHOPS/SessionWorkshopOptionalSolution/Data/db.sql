﻿CREATE DATABASE SessionsWorkshop
GO

USE SessionsWorkshop
GO

CREATE TABLE Sessions (
   [Id] nvarchar(100) NOT NULL,
   [UserId] int NOT NULL,
   PRIMARY KEY (Id)
)

CREATE TABLE Users (
   [Id] int NOT NULL,
   [Username] nvarchar(50) NOT NULL,
   [Password] nvarchar(100) NOT NULL
   PRIMARY KEY (Id)
)

CREATE TABLE Clicks(
   [UserId] int NOT NULL,
   [ClickedButtons] nvarchar(500) NOT NULL,
   PRIMARY KEY (UserId)
)
GO

INSERT INTO Users([Id], [Username], [Password]) 
   VALUES (1, 'adam', 'adam');
GO