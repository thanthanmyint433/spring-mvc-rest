﻿using SessionWorkshop.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SessionWorkshop.Data
{
   public class SessionData : Data
   {
      public static Session GetSessionById(string sessionId)
      {
         Session session = null;

         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            string sql = @"SELECT Id, UserId 
                           FROM Sessions
                           WHERE Id = '" + sessionId + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
               session = new Session
               {
                  Id = (string)reader["Id"],
                  UserId = (int)reader["UserId"]
               };

            }
         }

         return session;
      }

      public static int CreateSession(Session session)
      {
         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            // This session has no expiry. In reality, sessions should have expiry
            string sql = string.Format("INSERT INTO Sessions (Id, UserId) " +
                                                     "VALUES ('{0}', {1})", session.Id, session.UserId);
            SqlCommand cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteNonQuery();
         }
      }

      public static int DeleteSesion(string sessionId)
      {
         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            // Deleting records in DBs is rare in reality. Often, the record is just disabled using a IsActive column
            string sql = string.Format("DELETE FROM Sessions " +
                                                     "WHERE Id = '{0}'", sessionId);
            SqlCommand cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteNonQuery();
         }
      }
   }
}
