﻿using SessionWorkshop.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SessionWorkshop.Data
{
   public class UserData : Data
   {
      public static User GetUserByUsername(string username)
      {
         User user = null;

         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            string sql = @"SELECT Id, Username, Password 
                           FROM Users
                           WHERE Username = '" + username + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
               user = new User
               {
                  Id = (int)reader["Id"],
                  Username = (string)reader["Username"],
                  Password = ((string)reader["Password"]).Trim()
               };

            }
         }

         return user;
      }

      public static User GetUserById(int id)
      {
         User user = null;

         using (SqlConnection conn = new SqlConnection(connectionString))
         {
            conn.Open();
            // This query is weak, use SQLParameter in your real projects instead
            string sql = @"SELECT Id, Username 
                           FROM Users
                           WHERE Id = " + id;
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
               user = new User
               {
                  Id = (int)reader["Id"],
                  Username = (string)reader["Username"],
               };

            }
         }

         return user;
      }
   }
}
