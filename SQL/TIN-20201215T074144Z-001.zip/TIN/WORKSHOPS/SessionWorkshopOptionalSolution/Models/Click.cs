﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SessionWorkshop.Models
{
   public class Click
   {
      public int UserId { set; get; }
      public string ClickButtons { set; get; }
   }
}
