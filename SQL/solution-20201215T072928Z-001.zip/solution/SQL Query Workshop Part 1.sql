Note: In some question, there may be more than 1 approach!
===

-- Workshop on SQL Query
-- 1 a)
select * from Shippers;

-- 1 b)
select * from Shippers
order By CompanyName;

-- 2 a)
select FirstName,LastName,Title,BirthDate,City
from Employees;

-- 2 b)
select Distinct Title
from Employees;

-- 3)

-- SQL Server
select * from Orders
where OrderDate='19 May 1997';

-- MySQL
select * from Orders
where date_format(OrderDate, '%d %M %Y') ='19 May 1997';

-- 4)
select * from Customers
where City='London'
or City='Madrid';

-- 5)
select CustomerID,ContactName
from Customers
where Country='UK'
order By ContactName;


-- 6)
select OrderID,OrderDate
from Orders
where CustomerID='HANAR';


-- 7)
-- SQLServer Syntax
select(TitleOfCourtesy+FirstName+LastName) as EmployeeName
from Employees order by LastName;

-- MySQL Syntax
select concat( TitleOfCourtesy, " ", FirstName, " ", LastName) as EmployeeName
from Employees order by LastName;

-- 8)
-- Using subquery
select OrderID,OrderDate
from Orders where CustomerId in 
	(select Customerid 
	 from Customers
     where Companyname ='Maison Dewey');

-- Using join
select OrderID,OrderDate
from Orders,Customers
where Orders.CustomerID=Customers.CustomerID
and Customers.CompanyName='Maison Dewey';

-- 9)
select * from products
where productname like '%lager%';

-- 10)
select CustomerID,ContactName
from Customers
where CustomerID not IN (select distinct CustomerID
                         from Orders);

-- 11)
select avg (unitprice) 
from products

-- 12)
select distinct city 
from customers

-- 13)
select count(distinct customerid) 
from orders

-- 14)
select CompanyName, Phone
from Customers 
where fax is null

-- 15)
select sum (UnitPrice * Quantity)
from [Order Details]

-- 16)
select OrderID
from orders
where orders.CustomerID in
	(select CustomerID 
	 from Customers
	 where Customers.CompanyName in ('Alan Out', 'Blone Coy'))





